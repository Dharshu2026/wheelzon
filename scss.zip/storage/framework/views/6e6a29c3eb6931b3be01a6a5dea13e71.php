<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>

<style>
    
    body {
        background: #111;
    }

    .login-container {
        max-width: 420px;
        margin: 60px auto;
        background: #1c1c1c;
        padding: 40px 30px;
        border-radius: 15px;
        box-shadow: 0 0 18px rgba(255, 100, 0, 0.2);
        color: #fff;
    }

    .login-container h2 {
        font-weight: 600;
        color: #ff7300;
    }

    .form-control {
        background: #2a2a2a;
        color: white;
        border: 1px solid #444;
        height: 48px;
    }

    .form-control:focus {
        background: #333;
        color: #fff;
        border-color: #ff7300;
        box-shadow: 0 0 10px rgba(255, 115, 0, 0.5);
    }

    .btn-orange {
        background: #ff7300;
        color: white;
        border-radius: 8px;
        height: 45px;
        font-weight: 600;
        border: none;
    }

    .btn-orange:hover {
        background: #ff8c1a;
        color: #fff;
    }

    a.text-warning:hover {
        color: #ffae42 !important;
    }
</style>

<div class="login-container">

    <h2 class="text-center mb-4">LOGIN</h2>

    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
          <ul class="mb-0">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('login')); ?>">
      <?php echo csrf_field(); ?>

      <div class="mb-3">
        <input type="email" name="email" class="form-control" placeholder="Email" required autofocus>
      </div>

      <div class="mb-3">
        <input type="password" name="password" class="form-control" placeholder="Password" required>
      </div>

      <div class="mb-3 form-check">
        <input type="checkbox" class="form-check-input" name="remember" id="remember">
        <label class="form-check-label" for="remember">Remember Me</label>
      </div>

      <button type="submit" class="btn btn-orange w-100">Login</button>

    </form>

    <p class="text-center mt-3">
        Don't have an account?  
        <a href="<?php echo e(route('register')); ?>" class="text-warning">Register</a>
    </p>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\project\bike\wheelzon\resources\views/auth/login.blade.php ENDPATH**/ ?>